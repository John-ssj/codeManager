//
//  SideButtonsView.swift
//  newmooc
//
//  Created by apple on 2020/10/4.
//

import UIKit
import Foundation

// 侧边栏页面
class SideButtonsView: UIView {
    
    var myDelegate: SideBarViewDelegate?
    
    var draftPaperTag = 0
    var tapeViewTag = 0
    
    var logoIV = UIImageView()  // 登陆头像
    lazy var withdrawBtn = SideBtn()  // 撤回
    var cutBtn = SideBtn()  // 剪除
    var eraserBtn = SideBtn()  // 橡皮
    var pathBtn = SideBtn()  // 书写
    var lineAndWavyLineBtn = SideBtn()  // 线条
    var arrowBtn = SideBtn()  // 箭头
    var pointerBtn = SideBtn()  // 教鞭
    var clearBtn = SideBtn()  // 清空
    
    var btnList = [SideBtn]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(displayP3Red: 29/255, green: 30/255, blue: 33/255, alpha: 1.0)
        
        logoIV.image = UIImage(named: "logo")
        self.addSubview(logoIV)
        
        setupButtons()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        logoIV.frame = CGRect(x: 5, y: 10, width: 50, height: 50)
        withdrawBtn.frame = CGRect(x: SideBarPaddingW, y: 7*SideBarPaddingH, width: buttonW, height: buttonH)
        cutBtn.frame = CGRect(x: SideBarPaddingW, y: withdrawBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        eraserBtn.frame = CGRect(x: SideBarPaddingW, y: cutBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        pathBtn.frame = CGRect(x: SideBarPaddingW, y: eraserBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        lineAndWavyLineBtn.frame = CGRect(x: SideBarPaddingW, y: pathBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        arrowBtn.frame = CGRect(x: SideBarPaddingW, y: lineAndWavyLineBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        pointerBtn.frame = CGRect(x: SideBarPaddingW, y: arrowBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        clearBtn.frame = CGRect(x: SideBarPaddingW, y: pointerBtn.frame.maxY+SideBarPaddingH, width: buttonW, height: buttonH)
        
    }
    
    
    func setupButtons() {
        withdrawBtn.setTitle("撤回", for: .normal)
        withdrawBtn.setImage(imageNamed: "withdraw")
        withdrawBtn.btnType = .withdraw
        withdrawBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(withdrawBtn)
        
        cutBtn.setTitle("剪除", for: .normal)
        cutBtn.setImage(imageNamed: "cut")
        cutBtn.btnType = .Cut
        cutBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(cutBtn)
        self.btnList.append(cutBtn)
        
        eraserBtn.setTitle("橡皮", for: .normal)
        eraserBtn.setImage(imageNamed: "eraser")
        eraserBtn.btnType = .Eraser
        eraserBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(eraserBtn)
        self.btnList.append(eraserBtn)
        
        pathBtn.setTitle("书写", for: .normal)
        pathBtn.setImage(imageNamed: "pencil")
        pathBtn.btnType = .Path
        pathBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(pathBtn)
        self.btnList.append(pathBtn)
        
        lineAndWavyLineBtn.setTitle("线条", for: .normal)
        lineAndWavyLineBtn.setImage(imageNamed: "ruler")
        lineAndWavyLineBtn.btnType = .lineAndWavyLineBtn
        lineAndWavyLineBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(lineAndWavyLineBtn)
        self.btnList.append(lineAndWavyLineBtn)
        
        arrowBtn.setTitle("箭头", for: .normal)
        arrowBtn.setImage(imageNamed: "arrow")
        arrowBtn.btnType = .Arrow
        arrowBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(arrowBtn)
        self.btnList.append(arrowBtn)
        
        pointerBtn.setTitle("教鞭", for: .normal)
        pointerBtn.setImage(imageNamed: "pointer")
        pointerBtn.btnType = .Pointer
        pointerBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(pointerBtn)
        self.btnList.append(pointerBtn)
        
        clearBtn.setTitle("清空", for: .normal)
        clearBtn.setImage(imageNamed: "clearpage")
        clearBtn.btnType = .Clear
        clearBtn.addTarget(self, action: #selector(SideBtnClicked), for: .touchUpInside)
        self.addSubview(clearBtn)
        
        
        
    }
    
    
    @objc func SideBtnClicked(sender: SideBtn) {
        myDelegate?.SideBtnClickedWithTag(tag: sender.btnType!)
        if sender.btnType != .withdraw || sender.btnType != .Clear {
            changeBtnImgWithTag(btnWithTag: sender)
        }
    }
    
    func changeBtnImgWithTag(btnWithTag: SideBtn) {
        for btn in btnList {
            btn.isUsed = (btn == btnWithTag)
        }
    }
    
}


protocol SideBarViewDelegate {
    func SideBtnClickedWithTag(tag: SideButtonType)
}
