//
//  ViewController.swift
//  mooc-v1
//
//  Created by apple on 2020/10/6.
//


import UIKit

class ViewController: UIViewController {
    
    var sideBtnView: SideButtonsView!
    var drawPopView: DrawPopButtonsView!
    var boardView: mainDrawingView!
    
    // 隐藏StatusBar，但是会显示NavigationBar，需要在viewDidLoad再次隐藏
    override var prefersStatusBarHidden: Bool {
            return true
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor.white
        self.navigationController?.isNavigationBarHidden = true
        
        setupSideBtnView()
        setupBoardView()
        setupDrawPopView()
    }

    
    func setupSideBtnView() {
        sideBtnView = SideButtonsView(frame: CGRect(x: 0, y: 0, width: SideBarW, height: ScreenH))
        self.view.addSubview(sideBtnView)
        sideBtnView.myDelegate = self
    }
    
    func setupDrawPopView() {
        drawPopView = DrawPopButtonsView(frame: CGRect(x: SideBarW, y: 0, width: ScreenW - SideBarW, height: ScreenH))
        self.view.addSubview(drawPopView)
        drawPopView.isHidden = true
        
        // 每次关闭drawPopView会调用此闭包
        drawPopView.dissmissView = {
            // 让maskview的画笔颜色粗细等于drawPopView中的颜色粗细
            self.drawPopView.isHidden = true
            self.boardView.pathWidth = self.drawPopView.LineWidth
            self.boardView.pathColor = self.drawPopView.LineColor
            print(self.boardView.pathWidth)
        }
    }
    
    func setupBoardView() {
        boardView = mainDrawingView(frame: CGRect(x: SideBarW, y: 0, width: ScreenW-SideBarW, height: ScreenH))
        self.view.addSubview(boardView)
    }

}

// SideBarViewDelegate侧边栏按钮，点击后改变主图画界面的画笔类型
extension ViewController: SideBarViewDelegate {
    func SideBtnClickedWithTag(tag: SideButtonType) {
        self.drawPopView.isHidden = true
        switch tag {
        case .Path:
            self.drawPopView.isHidden = false
            self.boardView.lineType = .LineTypePath
        case .Arrow:
            self.boardView.lineType = .LineTypeArrow
        case .lineAndWavyLineBtn:
            self.boardView.lineType = .LineTypeStraightLine
        case .Pointer:
            self.boardView.lineType = .LineTypePointer
        default:
            break
        }
    }
}

