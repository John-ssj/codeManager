//
//  SideBtn.swift
//  newmooc
//
//  Created by apple on 2020/10/4.
//

import UIKit
import Foundation

// 自定义侧边栏按钮，使其左边为图片，右边为按钮名字
class SideBtn: UIButton {
    
    var btnImgName = ""
    var btnType: SideButtonType?
    
    // isUsed在每次点击按钮时会set。使按钮在被按下后保持绿色，并把别的所有按钮边灰色
    var isUsed = false {
        willSet(newvalue) {
            if newvalue == false {
                self.setImage(UIImage(named: btnImgName)?.withRenderingMode(.alwaysOriginal), for: .normal)
                self.setTitleColor(SiderBarGlary, for: .normal)
            } else {
                self.setImage(UIImage(named: "in"+btnImgName)?.withRenderingMode(.alwaysOriginal), for: .normal)
                self.setTitleColor(SiderBarGreen, for: .normal)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.clear
        self.tintColor = UIColor.clear
        self.setTitleColor(SiderBarGlary, for: .normal)
        self.setTitleColor(SiderBarGreen, for: .highlighted)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        let viewW = Int(self.frame.size.width)
        let viewH = Int(self.frame.size.height)
        let padding = 2;
        let topSpace = 8;

        self.imageView?.frame = CGRect(x: padding, y: topSpace, width: viewH-2*topSpace, height: viewH-2*topSpace)
        self.titleLabel?.frame = CGRect(x: Int(imageView!.frame.maxX) + padding, y: 0, width: viewW - Int(imageView!.frame.size.width) - 3 * padding, height: viewH)
        self.titleLabel?.adjustsFontSizeToFitWidth = true
        self.titleLabel?.textAlignment = .center
    }
    
    func setImage(imageNamed imageName: String) {
        super.setImage(UIImage(named: imageName)?.withRenderingMode(.alwaysOriginal), for: .normal)
        super.setImage(UIImage(named: "in"+imageName)?.withRenderingMode(.alwaysOriginal), for: .highlighted)
        self.btnImgName = imageName
    }
}
