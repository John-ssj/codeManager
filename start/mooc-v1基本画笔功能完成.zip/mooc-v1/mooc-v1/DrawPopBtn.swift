//
//  DrawPopBtn.swift
//  newmooc
//
//  Created by apple on 2020/10/5.
//

import UIKit
import Foundation

class DrawPopBtn: UIButton {
    
    enum pencilType {
        case lineWidth(width: LineWidthType)
        case lineColor(color: UIColor)
    }
    
    var btnTag: pencilType?
    
    init(frame: CGRect, tag: pencilType) {
        super.init(frame: frame)
        self.btnTag = tag
        self.frame = frame
//        self.layer.masksToBounds = true
        
        switch btnTag {
        case .lineWidth:
            self.setImage(UIColor.black.image(), for: .normal)
        case .lineColor(let color):
            self.setImage(color.image(), for: .normal)
        default: break
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let viewW: CGFloat = BtnWH
        let viewH: CGFloat = BtnWH
        let padding: CGFloat = 10
        let colorIXY: CGFloat = 3
        let colorIWH: CGFloat = viewW - colorIXY * 2
        
        switch btnTag {
        case .lineWidth(let width):
            let K:CGFloat = CGFloat(2.0 - Double(width.rawValue)/6.0)
            self.imageView?.frame = CGRect(x: K * padding, y: K * padding, width: viewW - K * padding*2, height: viewH - K * padding*2)
            self.imageView?.layer.cornerRadius = (viewW - K * padding*2)/2
        case .lineColor:
            self.imageView?.frame = CGRect(x: colorIXY, y: colorIXY, width: colorIWH, height: colorIWH)
            self.imageView?.layer.cornerRadius = colorIWH/2
        default: break
        }
        
    }
}


// 拓展UIColor,利用颜色创建纯色UIImage
extension UIColor {
    func image(_ size: CGSize = CGSize(width: 1, height: 1)) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { rendererContext in
            self.setFill()
            rendererContext.fill(CGRect(origin: .zero, size: size))
        }
    }
}
