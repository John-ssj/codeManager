//
//  MaskView.swift
//  newmooc
//
//  Created by apple on 2020/10/4.
//

import UIKit
import Foundation

class MaskView: UIView {
    
    var allStrokeArray: NSMutableArray!
    var anotherLineWidth:CGFloat = 1
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func draw(_ rect: CGRect) {
        let mustReStrokeArray = getmustReStrokeArrayWithRect(rect: rect)
        
        super.draw(rect)
        guard let context = UIGraphicsGetCurrentContext() else { return }
        context.setLineCap(.round)
        context.setLineJoin(.round)
        context.setMiterLimit(3)
        
        for _singlePathDic in mustReStrokeArray {
            let singlePathDic = _singlePathDic as! NSMutableDictionary
            let line_type = singlePathDic.value(forKey: "lineType") as! LineType
            
            switch line_type {
            case .LineTypePath: self.drawPathWithContext(context: context, andPathDic: singlePathDic)
            default: break
            }
            
        }
    }
    

    func getmustReStrokeArrayWithRect(rect: CGRect) -> NSMutableArray {
        let mustReStrokeArray = NSMutableArray()
        let tmpArray = self.allStrokeArray.mutableCopy() as! NSMutableArray
        
        for _mutableDic in tmpArray {
            let mutableDic = _mutableDic as! NSMutableDictionary
            let line_type = mutableDic.value(forKey: "lineType") as! LineType
            if line_type == .LineTypeArrow {
                mustReStrokeArray.add(mutableDic)
            } else {
                let points = mutableDic.value(forKey: "point") as! NSMutableArray
                for _dictionary in points {
                    let dictionary = _dictionary as! NSDictionary
                    let point = dictionary.value(forKey: "point") as! CGPoint
                    let isContain = CGRect(x: rect.minX - BushSize, y: rect.minY - BushSize, width: rect.width + 2*BushSize, height: rect.height + 2*BushSize).contains(point)
                    if isContain {
                        mustReStrokeArray.add(mutableDic)
                        break
                    }
                }
            }
        }
        
        return mustReStrokeArray
    }
    
    
    func drawPathWithContext(context: CGContext, andPathDic pathDic :NSDictionary) {
        let singleStrokeArray = pathDic.value(forKey: "point") as! NSMutableArray
        let _lineWidth = pathDic.value(forKey: "lineWidth") as! LineWidthType
        let lineWidth = _lineWidth.rawValue
        let lineColor = pathDic.value(forKey: "lineColor") as! UIColor
        lineColor.setStroke()
        
        if singleStrokeArray.count < 4 {
            
            if singleStrokeArray.count == 2 {
                let bezier = UIBezierPath()
                bezier.move(to: UnpackToPoint(from: singleStrokeArray, at: 0)!)
                bezier.addLine(to: UnpackToPoint(from: singleStrokeArray, at: 1)!)
                let force:CGFloat = (UnpackToforce(from: singleStrokeArray, at: 0)!+UnpackToforce(from: singleStrokeArray, at: 1)!) / 2.0
                bezier.lineWidth = 4*force
                context.addPath(bezier.cgPath)
                context.drawPath(using: .stroke)
                
            }else if singleStrokeArray.count == 3 {
                let bezier = UIBezierPath()
                bezier.move(to: UnpackToPoint(from: singleStrokeArray, at: 0)!)
                bezier.addQuadCurve(to: UnpackToPoint(from: singleStrokeArray, at: 2)!, controlPoint: UnpackToPoint(from: singleStrokeArray, at: 1)!)
                let force:CGFloat = (UnpackToforce(from: singleStrokeArray, at: 0)!+UnpackToforce(from: singleStrokeArray, at: 1)!+UnpackToforce(from: singleStrokeArray, at: 2)!) / 2.0
                bezier.lineWidth = 4*force
                context.addPath(bezier.cgPath)
                context.drawPath(using: .stroke)
            }
            
        } else {
            let count:Int = (singleStrokeArray.count - 4)/2 + 1
            
            for i in 0..<count {
                let start = UnpackToPoint(from: singleStrokeArray, at: 2*i)!
                let end = UnpackToPoint(from: singleStrokeArray, at: 2*i+3)!
                let controlPoint1 = UnpackToPoint(from: singleStrokeArray, at: 2*i+1)!
                let controlPoint2 = UnpackToPoint(from: singleStrokeArray, at: 2*i+2)!
                
                let startPoint = CGPoint(x: (start.x + controlPoint1.x)/2.0, y: (start.y + controlPoint1.y)/2.0)
                let endPoint = CGPoint(x: (end.x + controlPoint2.x)/2.0, y: (end.y + controlPoint2.y)/2.0)
                
                let bezier = UIBezierPath()
                bezier.move(to: startPoint)
                bezier.addCurve(to: endPoint, controlPoint1: controlPoint1, controlPoint2: controlPoint2)
                
                //连上最后一个点
                if ((singleStrokeArray.count%2) != 0) && (i == count-1) {
                    bezier.addLine(to: UnpackToPoint(from: singleStrokeArray, at: singleStrokeArray.count - 1)!)
                }
                
                var force: CGFloat = 0
                if i == 0{
                    //i=0的时候计算压力的时候就是只能用这四个点
                    force = (UnpackToforce(from: singleStrokeArray, at: 2*i)! +
                            UnpackToforce(from: singleStrokeArray, at: 2*i+1)! +
                            UnpackToforce(from: singleStrokeArray, at: 2*i+2)! +
                            UnpackToforce(from: singleStrokeArray, at: 2*i+3)!)/4.0
                } else {
                    let currentForce = (0.5*UnpackToforce(from: singleStrokeArray, at: 2*i)! +
                            1.5*UnpackToforce(from: singleStrokeArray, at: 2*i+1)! +
                            1.5*UnpackToforce(from: singleStrokeArray, at: 2*i+2)! +
                            0.5*UnpackToforce(from: singleStrokeArray, at: 2*i+3)!)/4.0
                    
                    let lastForce = (0.5*UnpackToforce(from: singleStrokeArray, at: 2*i-2)! +
                            1.5*UnpackToforce(from: singleStrokeArray, at: 2*i-1)! +
                            1.5*UnpackToforce(from: singleStrokeArray, at: 2*i)! +
                            0.5*UnpackToforce(from: singleStrokeArray, at: 2*i+1)!)/4.0
                    
                    force = 2/3.0 * currentForce + 1/3.0 * lastForce
                }
                
                bezier.lineWidth = force*lineWidth*0.5+lineWidth*0.5 + anotherLineWidth
                context.addPath(bezier.cgPath)
                context.drawPath(using: .stroke)
            }
            
        }
        
    }
    
    
    // 解包专用！
    fileprivate func UnpackToPoint(from array: NSMutableArray, at n: Int) -> CGPoint? {
        if n >= array.count { return nil }
        if let dic = array[n] as? NSMutableDictionary {
            return dic.value(forKey: "point") as? CGPoint
        }
        return nil
    }
    
    fileprivate func UnpackToforce(from array: NSMutableArray, at n: Int) -> CGFloat? {
        if n >= array.count { return nil }
        if let dic = array[n] as? NSMutableDictionary {
            return dic.value(forKey: "force") as? CGFloat
        }
        return nil
    }
}
