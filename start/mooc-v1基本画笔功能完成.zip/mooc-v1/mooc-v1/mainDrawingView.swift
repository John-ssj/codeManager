//
//  mainDrawingView.swift
//  newmooc
//
//  Created by apple on 2020/10/4.
//

import UIKit
import Foundation

class mainDrawingView: UIView {
    
    var lineType:LineType = .LineTypePath
    var pathColor:UIColor = .black
    var pathWidth:LineWidthType = .Thin
    
    var allStrokeArray = NSMutableArray()
    var points = NSMutableArray()
    var _dic = NSMutableDictionary()
    
    var maskview: MaskView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor(red: 241/155, green: 221/255, blue: 170/255, alpha: 1)
        
        maskview = MaskView(frame: self.bounds)
        maskview.allStrokeArray = self.allStrokeArray
        self.addSubview(maskview)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let startPos = touch.location(in: maskview)
        
        points.removeAllObjects()
        _dic.removeAllObjects()

        if self.lineType == .LineTypePath {
            let pointDic = NSMutableDictionary()
            pointDic.setValue(startPos, forKey: "point")
            pointDic.setValue(touch.force == 0 ? 1 : touch.force, forKey: "force")
            
            let d = NSMutableDictionary()
            d.setValue(startPos.x, forKey: "x")
            d.setValue(startPos.y, forKey: "y")
            d.setValue(touch.force == 0 ? 1 as CGFloat : touch.force as CGFloat, forKey: "force")
            points.add(d)
            
            let singleStrokeArray = NSMutableArray()
            singleStrokeArray.add(pointDic)

            let pathDic = NSMutableDictionary()
            pathDic.setValue(pathWidth, forKey: "lineWidth")
            pathDic.setValue(pathColor, forKey: "lineColor")
            pathDic.setValue(lineType, forKey: "lineType")
            pathDic.setValue(singleStrokeArray, forKey: "point")
            
            _dic.setValue(pathWidth.rawValue, forKey: "width")
            _dic.setValue(pathColor.accessibilityName, forKey: "color")
            _dic.setValue(lineType.rawValue, forKey: "type")
            
            self.allStrokeArray.add(pathDic)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let currentPos = touch.location(in: maskview)
        
//        print(self.allStrokeArray.lastObject as Any)
        if self.lineType == .LineTypePath {
            let dic = self.allStrokeArray.lastObject as! NSMutableDictionary
            let singleStrokeArray = dic["point"] as! NSMutableArray
            
            let d = NSMutableDictionary()
            d.setValue(currentPos.x, forKey: "x")
            d.setValue(currentPos.y, forKey: "y")
            d.setValue(touch.force == 0 ? 1 as CGFloat : touch.force as CGFloat, forKey: "force")
            points.add(d)
            
            let pointDic = NSMutableDictionary()
            pointDic.setValue(currentPos, forKey: "point")
            pointDic.setValue(touch.force == 0 ? 1 : touch.force, forKey: "force")
            
            singleStrokeArray.add(pointDic)
        }
        
        self.maskview.setNeedsDisplay(getRefreshRect())
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let currentPos = touch.location(in: maskview)
        
        if self.lineType == .LineTypePath {
            let dic = self.allStrokeArray.lastObject as! NSMutableDictionary
            let singleStrokeArray = dic["point"] as! NSMutableArray
            
            let pointDic = NSMutableDictionary()
            pointDic.setValue(currentPos, forKey: "point")
            pointDic.setValue(touch.force == 0 ? 1 : touch.force, forKey: "force")
            
            let d = NSMutableDictionary()
            d.setValue(currentPos.x, forKey: "x")
            d.setValue(currentPos.y, forKey: "y")
            d.setValue(touch.force == 0 ? 1 as CGFloat : touch.force as CGFloat, forKey: "force")
            points.add(d)
            
            singleStrokeArray.add(pointDic)
            _dic.setValue(points, forKey: "points")
        }
        
        self.changeToJsonAndPrint(dic: _dic)
        self.maskview.setNeedsDisplay(getRefreshRect())
    }

    
    func getRefreshRect() -> CGRect {
        let dic:NSDictionary = self.allStrokeArray.lastObject as! NSDictionary
        let singleStrokeArray:NSMutableArray = dic["point"] as! NSMutableArray
        var singlePointXArray = [CGFloat]()
        var singlePointYArray = [CGFloat]()
        for dic in singleStrokeArray {
            let d = dic as! NSDictionary
            let n = d.value(forKey: "point") as! CGPoint
            singlePointXArray.append(n.x)
            singlePointYArray.append(n.y)
        }
        
        let maxX:CGFloat = singlePointXArray.max() ?? 0
        let minX:CGFloat = singlePointXArray.min() ?? 0
        let maxY:CGFloat = singlePointYArray.max() ?? 0
        let minY:CGFloat = singlePointYArray.min() ?? 0
        let rect = CGRect(x: minX-BushSize, y: minY-BushSize, width: maxX-minX+2*BushSize, height: maxY-minY+2*BushSize)
        return rect
    }
    
    
    func changeToJsonAndPrint(dic: NSMutableDictionary) {
        let canChange = JSONSerialization.isValidJSONObject(dic)
        if !canChange {
            NSLog("Change To Json Faild!")
            return
        }
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: dic, options: .fragmentsAllowed)
            let path = "/Users/apple/Desktop/datta.json"
            let fm = FileManager()
            
            if !fm.fileExists(atPath: path) {
                fm.createFile(atPath: path, contents: nil, attributes: nil)
            }
            if let fh = FileHandle(forWritingAtPath: path) {
                fh.seekToEndOfFile()
                fh.write(jsonData)
                fh.write("\n\n".data(using: String.Encoding.utf8)!)
                try fh.close()
            }
            
        }catch {
            NSLog("Change To Json Faild!")
        }
    }
    
}
