//
//  GlobalConstant.swift
//  newmooc
//
//  Created by apple on 2020/10/4.
//

import UIKit

// 存放所有全局变量
public let ScreenW:CGFloat = UIScreen.main.bounds.size.height
public let ScreenH:CGFloat = UIScreen.main.bounds.size.width
public let ScreenK:CGFloat = 1
public let SideBarW:CGFloat = 60
//public let drawingBoardDevY = ScreenK * ScreenH - (ScreenK * ScreenW - 100) * 4/3 - 10

// SideButtonsView，SideBtn页面
public let SideBarPaddingH:CGFloat = 10
public let SideBarPaddingW:CGFloat = 2
public let buttonW:CGFloat = SideBarW - SideBarPaddingW*2
public let buttonH:CGFloat = 40
public let SiderBarGreen = UIColor.systemGreen
public let SiderBarGlary = UIColor.lightGray

// DrawPopButtonsView，DrawPopBtn页面
public let DrawPopMainW:CGFloat = 240
public let DrawPopMainH:CGFloat = 220
public let BtnWH:CGFloat = 40
public let padding:CGFloat = 10

// mainDrawingView
public let BushSize:CGFloat = 20

// 侧边按钮类型
enum SideButtonType:String {
    case withdraw //撤回
    case Cut //剪除
    case Eraser //橡皮
    case Path  //普通笔
    case lineAndWavyLineBtn //线条
    case Arrow  //箭头
    case Pointer  //教鞭
    case Clear  //清空
}

// 画笔类型
enum LineType:String {
    case LineTypePath  = "path"//普通笔
    case LineTypeArrow = "arrow" //箭头
    case LineTypePointer = "pointer" //教鞭
    case LineTypeStraightLine = "straightLine" //直线
    case LineTypeWavyLine = "wavyLine" //波浪线
    case LineTypeEraser = "eraser" //橡皮
    case LineTypeCut = "cut" //剪除
}

// 画笔粗细
enum LineWidthType:CGFloat {
    case Thin = 2
    case Middle = 4
    case Thick = 6
}
