//
//  DrawPopButtonsView.swift
//  newmooc
//
//  Created by apple on 2020/10/5.
//

import UIKit
import Foundation

class DrawPopButtonsView: UIView {
    
    var LineColor = UIColor.black
    var LineWidth = LineWidthType.Thin
    
    var dissmissView: (() -> Void)?
    
    var mainView = UIView()
    var thinLineBtn: DrawPopBtn!
    var middleLineBtn: DrawPopBtn!
    var strongLineBtn: DrawPopBtn!

    var redColorBtn: DrawPopBtn!
    var blueColorBtn: DrawPopBtn!
    var blackColorBtn: DrawPopBtn!
    var brownColorBtn: DrawPopBtn!

    var purpleColorBtn: DrawPopBtn!
    var orangeColorBtn: DrawPopBtn!
    var cyanColorBtn: DrawPopBtn!
    var greenColorBtn: DrawPopBtn!

    var magentaColorBtn: DrawPopBtn!
    var grayColorBtn: DrawPopBtn!
    var yellowColorBtn: DrawPopBtn!
    var whiteColorBtn: DrawPopBtn!
    
    var allLineBtns = [DrawPopBtn]()
    var allColorBtns = [DrawPopBtn]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        
        setupBtns()
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if touches.first?.view != mainView {
            self.dissmissView?()
        }
    }
    
    func setupBtns() {
        mainView.frame = CGRect(x: 5, y: 120, width: DrawPopMainW, height: DrawPopMainH)
        mainView.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.8)
        mainView.layer.masksToBounds = true
        mainView.layer.borderColor = CGColor(red: 29/255, green: 30/255, blue: 33/255, alpha: 1)
        mainView.layer.borderWidth = 2
        mainView.layer.cornerRadius = DrawPopMainW * 0.1
        self.addSubview(mainView)
        
        // 线条粗细
        thinLineBtn = DrawPopBtn(frame: CGRect(x: 0.5*(DrawPopMainW - BtnWH*3 - padding*2), y: padding, width: BtnWH, height: BtnWH), tag: .lineWidth(width: .Thin))
        thinLineBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(thinLineBtn)
        allLineBtns.append(thinLineBtn)
        
        middleLineBtn = DrawPopBtn(frame: CGRect(x: thinLineBtn.frame.maxX + padding, y: padding, width: BtnWH, height: BtnWH), tag: .lineWidth(width: .Middle))
        middleLineBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(middleLineBtn)
        allLineBtns.append(middleLineBtn)

        strongLineBtn = DrawPopBtn(frame: CGRect(x: middleLineBtn.frame.maxX + padding, y: padding, width: BtnWH, height: BtnWH), tag: .lineWidth(width: .Thick))
        strongLineBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(strongLineBtn)
        allLineBtns.append(strongLineBtn)

        // 线条颜色1
        redColorBtn = DrawPopBtn(frame: CGRect(x: 0.5*(DrawPopMainW - BtnWH*4 - padding*3), y: thinLineBtn.frame.maxY + padding*2, width: BtnWH, height: BtnWH), tag: .lineColor(color: .red))
        redColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(redColorBtn)
        allColorBtns.append(redColorBtn)

        blueColorBtn = DrawPopBtn(frame: CGRect(x: redColorBtn.frame.maxX + padding, y: redColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .blue))
        blueColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(blueColorBtn)
        allColorBtns.append(blueColorBtn)

        blackColorBtn = DrawPopBtn(frame: CGRect(x: blueColorBtn.frame.maxX + padding, y: redColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .black))
        blackColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(blackColorBtn)
        allColorBtns.append(blackColorBtn)

        brownColorBtn = DrawPopBtn(frame: CGRect(x: blackColorBtn.frame.maxX + padding, y: redColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .brown))
        brownColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(brownColorBtn)
        allColorBtns.append(brownColorBtn)


        // 线条颜色2
        purpleColorBtn = DrawPopBtn(frame: CGRect(x: 0.5*(DrawPopMainW - BtnWH*4 - padding*3), y: redColorBtn.frame.maxY + padding, width: BtnWH, height: BtnWH), tag: .lineColor(color: .purple))
        purpleColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(purpleColorBtn)
        allColorBtns.append(purpleColorBtn)

        orangeColorBtn = DrawPopBtn(frame: CGRect(x: purpleColorBtn.frame.maxX + padding, y: purpleColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .orange))
        orangeColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(orangeColorBtn)
        allColorBtns.append(orangeColorBtn)

        cyanColorBtn = DrawPopBtn(frame: CGRect(x: orangeColorBtn.frame.maxX + padding, y: purpleColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .cyan))
        cyanColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(cyanColorBtn)
        allColorBtns.append(cyanColorBtn)

        greenColorBtn = DrawPopBtn(frame: CGRect(x: cyanColorBtn.frame.maxX + padding, y: purpleColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .green))
        greenColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(greenColorBtn)
        allColorBtns.append(greenColorBtn)


        // 线条颜色3
        magentaColorBtn = DrawPopBtn(frame: CGRect(x: 0.5*(DrawPopMainW - BtnWH*4 - padding*3), y: purpleColorBtn.frame.maxY + padding, width: BtnWH, height: BtnWH), tag: .lineColor(color: .magenta))
        magentaColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(magentaColorBtn)
        allColorBtns.append(magentaColorBtn)

        grayColorBtn = DrawPopBtn(frame: CGRect(x: magentaColorBtn.frame.maxX + padding, y: magentaColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .gray))
        grayColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(grayColorBtn)
        allColorBtns.append(grayColorBtn)

        yellowColorBtn = DrawPopBtn(frame: CGRect(x: grayColorBtn.frame.maxX + padding, y: magentaColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .yellow))
        yellowColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(yellowColorBtn)
        allColorBtns.append(yellowColorBtn)

        whiteColorBtn = DrawPopBtn(frame: CGRect(x: yellowColorBtn.frame.maxX + padding, y: magentaColorBtn.frame.minY, width: BtnWH, height: BtnWH), tag: .lineColor(color: .white))
        whiteColorBtn.addTarget(self, action: #selector(DrawBtnClicked), for: .touchUpInside)
        mainView.addSubview(whiteColorBtn)
        allColorBtns.append(whiteColorBtn)
        
        for btn in allColorBtns + allLineBtns {
            btn.layer.masksToBounds = true
            btn.layer.cornerRadius = BtnWH/2
            btn.layer.borderColor = CGColor(red: 0, green: 0, blue: 1, alpha: 1)
            btn.layer.borderWidth = (btn == thinLineBtn || btn == blackColorBtn) ? 1 : 0
        }
    }
    
    @objc func DrawBtnClicked(sender: DrawPopBtn) {
        switch sender.btnTag {
        case .lineColor(let color):
            self.LineColor = color
            for btn in allColorBtns {
                btn.layer.borderWidth = (sender == btn) ? 1 : 0
            }
        case .lineWidth(let width):
            self.LineWidth = width
            for btn in allLineBtns {
                btn.layer.borderWidth = (sender == btn) ? 1 : 0
            }
        default:break
        }
        _ = delay(0.2) {
            self.dissmissView?()
        }
    }
    
}
